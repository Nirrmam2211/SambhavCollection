import stubPage from '@/utils/stubPage';
export default stubPage('Account');
